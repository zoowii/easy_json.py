# coding: UTF-8
from __future__ import print_function
import collections
from datetime import datetime
import time
import json

__author__ = 'zoowii'


def default_json_serializer(obj):
    """Default JSON serializer."""

    if isinstance(obj, datetime):
        timestamp = time.mktime(obj.timetuple())
        return timestamp
    return obj


def get_private_properties(obj):
    if isinstance(obj, dict):
        d = obj
    elif hasattr(obj, '__dict__'):
        d = obj.__dict__
    else:
        raise RuntimeError('easy_json not support obj not dict and without __dict__')
    keys = d.keys()
    return filter(lambda x: x[:2] == '__', keys)


class JSON(object):
    default_encoding = 'UTF-8'

    @staticmethod
    def is_json_primitive_value(obj):
        if obj is None:
            return True
        clss = [int, str, bool, datetime]
        for cls in clss:
            if isinstance(obj, cls):
                return True
        return False

    @staticmethod
    def to_json_object(obj, serializer=default_json_serializer, ignore_keys=None):
        """
        将对象的__dict__属性序列化，
        排除掉对象的__no_json__属性(或者@property修饰过的方法)
        和__no_json_serialize__返回的列表包含的key，
        所有以__开头的属性（私有属性），以及值是函数的属性，
        还有参数中ignore_keys传入的字符串数组（如果有的话）
        """
        if JSON.is_json_primitive_value(obj):
            return serializer(obj)
        if isinstance(obj, dict):
            data = obj
        elif hasattr(obj, '__dict__'):
            data = obj.__dict__
        else:
            raise RuntimeError('easy_json not support obj not dict and without __dict__')
        no_serialize_keys = []
        if ignore_keys is not None:
            no_serialize_keys.extend(ignore_keys)
        no_serialize_keys.extend(get_private_properties(data))
        if hasattr(obj, '__no_json__') and obj.__no_json__ is not None:
            no_serialize_keys.extend(obj.__no_json__)
        if hasattr(obj, '__no_json_serialize__') and obj.__no_json_serialize__ is not None:
            no_serialize_keys.extend(obj.__no_json_serialize__)
        no_serialize_keys = set(no_serialize_keys)
        keys = set(data.keys()) - set(no_serialize_keys)
        res = {}
        for key in keys:
            val = data[key]
            if callable(val):
                continue
            if JSON.json_serializable(val):
                res[key] = JSON.to_json(val, serializer=serializer, ignore_keys=ignore_keys)
            else:
                res[key] = serializer(val)
        return res

    @staticmethod
    def json_serializable(obj):
        if isinstance(obj, dict) or hasattr(obj, '__dict__'):
            return True
        else:
            return False

    @staticmethod
    def to_json_array(data, serializer=default_json_serializer, ignore_keys=None):
        res = []
        for item in data:
            res.append(JSON.to_json(item, serializer=serializer, ignore_keys=ignore_keys))
        return res

    @staticmethod
    def to_json(data, serializer=default_json_serializer, ignore_keys=None):
        if isinstance(data, collections.Iterable):
            return JSON.to_json_array(data, serializer=serializer, ignore_keys=ignore_keys)
        else:
            return JSON.to_json_object(data, serializer=serializer, ignore_keys=ignore_keys)

    @staticmethod
    def from_json_to_object(s, cls, encoding=default_encoding):
        """
        将字典（或者json字符串）转换成类cls的对象
        要求类cls支持无参数的构造函数（或者*args, **kwargs这样的参数）
        不支持嵌套对象的反序列化，因为不知道属性的具体类型，所以没有办法进行类型转换
        """
        if isinstance(s, str):
            data = json.loads(s, encoding=encoding)
        else:
            data = s
        obj = cls()
        for key in data.keys():
            setattr(obj, key, data[key])
        return obj


    @staticmethod
    def from_json_to_array(s, cls, encoding=default_encoding):
        if isinstance(s, str):
            data = json.loads(s, encoding=encoding)
        else:
            data = s
        res = []
        for item in data:
            res.append(JSON.from_json(item, cls, encoding=encoding))
        return res

    @staticmethod
    def from_json(s, cls, encoding=default_encoding):
        if isinstance(s, str):
            data = json.loads(s, encoding=encoding)
        else:
            data = s
        if isinstance(data, list):
            return JSON.from_json_to_array(data, cls, encoding=encoding)
        else:
            return JSON.from_json_to_object(data, cls, encoding=encoding)
